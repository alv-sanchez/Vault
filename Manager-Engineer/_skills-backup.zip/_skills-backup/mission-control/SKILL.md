---
name: mission-control
description: >
  The mother dashboard. Tracks every active (In Progress) BMS epic with its full ticket tree —
  each ticket's status plus its GitHub PR / review state — in one self-contained, auto-refreshing
  HTML page in the Obsidian vault. Surfaces an "in review / open PR" band up top so nothing waiting
  on you gets lost. Writes mission-control.html + a timestamped snapshot into
  Manager-Engineer/Mission-Control. Invoke with "/mission-control", "refresh mission control",
  "mother dashboard", or "show me everything in flight".
license: MIT
metadata:
  author: alvaro
  version: "1.0"
---

# mission-control 🛰️

One page, everything live. Active epics → their tickets → status + PR/review. Data from **Jira** (status) + **GitHub** (PRs), rendered to HTML in the vault with a paper-trail snapshot each run.

## Constants
- Jira cloudId `12843674-078e-48ac-ae5c-d33914c3bfb7` · your accountId `712020:38e713f0-defd-468b-b422-26423a878525`
- Repo `Ohanafy/OHFY-Split` · browse `https://ohanafy.atlassian.net/browse` · PRs `https://github.com/Ohanafy/OHFY-Split/pull`
- Output: `…/Manager-Engineer/Mission-Control/` (configurable in `config.json` next to `render.mjs`)

## Run (steps)

### 1. Active epics
`searchJiraIssuesUsingJql`:
```
project = BMS AND issuetype = Epic AND labels = sf-tracker
  AND assignee = 712020:38e713f0-defd-468b-b422-26423a878525
  AND status = "In Progress" ORDER BY updated DESC
```

### 2. Ticket tree per epic
For each epic: `parent = <EPIC-KEY> ORDER BY key`. The Atlassian tool ignores `fields` and returns fat bodies → large results auto-save to a file. **Don't read them in;** `jq` the saved path for just what the tree needs:
```bash
jq -r '.issues.nodes[] | "\(.key)\t[\(.fields.issuetype.name)]\t\(.fields.status.name)\t\(.fields.status.statusCategory.name)\t\(.fields.summary)"' "<saved-file>"
```

### 3. Write the Jira-only base file
Your ONLY hand-assembly step. From steps 1–2, write `…/Mission-Control/mission-control.base.json` — epics with their full ticket tree, **status only, no org, no pr** (the gatherer adds those):
```json
{ "generated": "YYYY-MM-DD HH:MM", "stampFile": "YYYY-MM-DD-HHMM",
  "epics": [ { "key":"BMS-XXXX","title":"...","domain":"...","phase":"crawl|walk|run",
    "pinned": false, "summary":"one crisp line",
    "tickets": [ {"key":"BMS-YYYY","type":"Story|SPIKE|Demo","title":"...",
      "status":"<Jira status name>","statusCategory":"To Do|In Progress|Done"} ] } ] }
```
Include **every** child of every in-progress epic (nest them all — that's the full-visibility contract). `pinned: true` for parked epics (📌). `statusCategory` drives the bar (In Progress/Review → started; Backlog/To Do/Needs Refinement → to-do; Done → done). Strip `[REQ-###]` from epic titles; keep summaries tight.

### 4. Gather — auto-attach PR + org (deterministic, scripted)
```bash
node ~/.claude/skills/mission-control/gather.mjs
```
This is the part that used to be hand-done and got things wrong — now it's code. It reads `base.json`, runs `gh pr list` + `sf org list`, and writes `mission-control.json` with each ticket's `pr` and `org` filled in:
- **PR match:** BMS number in the branch **or** title, incl. multi-ticket titles like `BMS-4217/5636/5638` (only the first carries the prefix). One PR → many tickets. Prefers OPEN, then newest.
- **Org match:** own-number org → else epic-number org → else PR-branch-number org — **only if the alias actually exists in `sf org list`.** So an expired org shows as *none* (truthful), and an epic-bundled PR lands the whole epic on `ohfy-val-<epic>`. Never invented.
- If a ticket sits in an open PR but has **no org**, that org likely expired — flag it (keep-orgs-till-merge).

### 5. Render
```bash
node ~/.claude/skills/mission-control/render.mjs
```
Writes `mission-control.html`, `Snapshots/<stamp>.html`, appends `refresh-log.md`. Prints a one-line summary.

**So the whole refresh is: Jira (MCP) → base.json → `gather.mjs` → `render.mjs`.** Only the Jira pull needs you/MCP; PRs + orgs are fully automated. (A Jira API token would let a script do step 1–3 too — offer it if he wants zero-touch.)

### 6. Report
State epics / tickets / in-progress / **in-review-or-PR** / done, and read out the ⚡ attention band (anything in Review or with an open PR — that's what's waiting on him). Point at `mission-control.html`.

## The dashboard
Summary cards → **⚡ Needs your eyes** band (Review / open-PR tickets, with PR links) → one card per epic: progress bar + counts + a ticket table (key · type · title · colored status · PR w/ draft/review tag). Dark, self-contained, `<meta refresh>` auto-reloads (15 min default).

## Refresh & viewing
- Refresh: `/mission-control` or "refresh mission control". Hands-off: `/loop 30m /mission-control` (interactive session — Jira MCP needs your login).
- View: open `mission-control.html` via *Open in default app*, or `<iframe src="Mission-Control/mission-control.html" width="100%" height="900"></iframe>` in a note.

## Guardrails
- **Read-only** on Jira, GitHub, and the repo; only writes into the Mission-Control folder.
- Never pull ticket/PR bodies into context — always `jq` the saved file for the fields you need.
- Scope is **active (In Progress) epics** by design. To include Done epics, widen the step-1 JQL and add them (Done ones can stay collapsed as one-liners).
